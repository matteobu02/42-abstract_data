template <typename T>
typedef struct s_node
{
	bool color;
	struct s_node<T> *right;
	struct s_node<T> *left;
}	t_node;

template <typename T>
class RBT
{
	public:
		RBT() : _root(NULL) {}
		virtual ~RBT() {}

	private:
		t_node<T> *root;
};

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbucci <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/24 15:11:25 by mbucci            #+#    #+#             */
/*   Updated: 2022/07/26 14:45:04 by mbucci           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once

#include "iterators.hpp"
#include "functionnal.hpp"
#include "utility.hpp"

namespace ft
{
	template < class Key,
			 class T,
			 class Compare = ft::less<Key>,
			 class Alloc = allocator<ft::pair<const Key,T> >
			> class map
			{
				public:
					typedef Key											key_type;
					typedef T											mapped_type;
					typedef ft::pair<const key_type, mapped_type>		value_type;
					typedef Compare										key_compare;

					typedef Alloc										allocator_type;
					typedef typename allocator_type::reference			reference;
					typedef typename allocator_type::const_reference	const_reference;
					typedef typename allocator_type::pointer			pointer;
					typedef typename allocator_type::const_pointer		const_pointer;
					typedef ptrdiff_t									difference_type;
					typedef size_t										size_type;

					class value_compare : public ft::binary_function<value_type, value_type, bool>
					{
						private:
							friend class map;

						public:
							typedef bool		result_type;
							typedef value_type	first_argument_type;
							typedef value_type	second_argument_type;

							bool operator() (const value_type& x, const value_type& y)
							{ return (comp(x._first, y._first)); }

						protected:
							Compare _comp;
							value_compare (Compare c) : comp(c) {}
					};

				private:
			};
}

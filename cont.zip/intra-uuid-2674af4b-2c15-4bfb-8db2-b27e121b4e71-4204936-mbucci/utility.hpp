/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utility.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mbucci <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/18 19:29:36 by mbucci            #+#    #+#             */
/*   Updated: 2022/07/26 14:42:51 by mbucci           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once

namespace ft
{
	// PAIR
	template <class T1, class T2> struct pair
	{
		public:
			typedef T1	first_type;
			typedef T2	second_type;

			pair() {}

			template <class U, class V>
				pair (const pair<U,V>& pr)
				: _first(pr._first), _second(pr._second) {}

			pair (const first_type& a, const second_type& b)
				: _first(a), _second(b) {}

			pair& operator= (const pair& pr)
			{
				this->_first = pr._first;
				this->_second = pr._second;
			}

			template <class T1, class T2>
				bool operator== (const pair<T1,T2>& lhs, const pair<T1,T2>& rhs)
				{ return (lhs._first == rhs._first && lhs._second == rhs._second); }

			template <class T1, class T2>
				bool operator< (const pair<T1,T2>& lhs, const pair<T1,T2>& rhs)
				{ return (lhs._first < rhs._first || (!(rhs._first < lhs._first) && lhs._second < rhs._second)); }

		private:
			T1 _first;
			T2 _second;
	};

	template <class T1, class T2>
		bool operator!= (const pair<T1,T2>& lhs, const pair<T1,T2>& rhs)
		{ return !(lhs == rhs); }

	template <class T1, class T2>
		bool operator<= (const pair<T1,T2>& lhs, const pair<T1,T2>& rhs)
		{ return !(rhs < lhs); }

	template <class T1, class T2>
		bool operator> (const pair<T1,T2>& lhs, const pair<T1,T2>& rhs)
		{ return (rhs < lhs); }

	template <class T1, class T2>
		bool operator>= (const pair<T1,T2>& lhs, const pair<T1,T2>& rhs)
		{ return !(lhs < rhs); }

	// MAKE_PAIR
	template <class T1, class T2>
		pair<T1,T2> make_pair (T1 x, T2 y) { return (pair<T1,T2>(x, y)); }
}
